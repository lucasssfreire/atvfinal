/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;
import java.lang.System.Logger;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author lucas.ssfreire
 */
public class Conexao {
    
 private static final String DRIVER = "com.mysql.jdbc.Driver";
 
 private static String URL = "jdbc:mysql://localhost:3306/petshop";
 
 private static String USER = "root";
 
 private static final String PASS = "";
 
 public static Connection getConnection(){
     try{
         Class.forName(DRIVER);
         return DriverManager.getConnection(URL, USER, PASS);
         
     }catch (Exception ex){
         throw new RuntimeException("Erro na conexão: ", ex);
     }
    }
 public static void closeConnection(Connection con){
     try{
         if(con !=null){
             con.close();
         }
     }catch (Exception ex){
         Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
     }
 }
    
}
